import copy
import pandas as pd
from models.db_schema_models import DatabaseSchemaInfoModel
from models.reporting_models import DatabaseSchemaReportingModel
from utils.general_opr import _dict_to_json_serializable, _write_dict_to_json_file


class DBAnalysisReportingUtils:
    
    @staticmethod
    def dbanalysis_report_to_json(obj: DatabaseSchemaReportingModel | DatabaseSchemaInfoModel, file_path: str):
        
        _write_dict_to_json_file(_dict_to_json_serializable(obj.model_dump()), file_path)

    @staticmethod
    def dbanalysis_report_to_excel(obj: DatabaseSchemaReportingModel | DatabaseSchemaInfoModel, file_path: str):
        
        if isinstance(obj, DatabaseSchemaInfoModel):
            obj = DatabaseSchemaReportingModel(list_database_schema_info=[obj])
        
        database_schema_info_tabular_format = []
        collection_schema_info_tabular_format = []
        collection_index_details_tabular_format = []
        doc_schema_info_tabular_format = []
        
        for db_schema_info in obj.list_database_schema_info:
            database_schema_info_tabular_format.append(DBAnalysisReportingUtils.database_schema_info_to_tabular_format(db_schema_info))
            collection_schema_info_tabular_format.extend(DBAnalysisReportingUtils.collection_schema_info_to_tabular_format(db_schema_info))
            collection_index_details_tabular_format.extend(DBAnalysisReportingUtils.collection_index_details_to_tabular_format(db_schema_info))
            doc_schema_info_tabular_format.extend(DBAnalysisReportingUtils.doc_schema_info_to_tabular_format(db_schema_info))
        
        df_database_schema_info = pd.DataFrame(database_schema_info_tabular_format)
        df_collection_schema_info = pd.DataFrame(collection_schema_info_tabular_format)
        df_collection_index_details = pd.DataFrame(collection_index_details_tabular_format).loc[
            :, 
            ['db_nm', 'col_nm', 'collection_ns', 'index_name', 'index_size', 'v', 'key', 'fetch_datetime']
        ]
        df_doc_schema_details = pd.DataFrame(doc_schema_info_tabular_format) \
            .drop(
                columns = ['parent_path', 'parent_data_type']
            )\
            .sort_values(
                by = ['db_nm', 'col_nm', 'path'],
                ascending = [True, True, True]
            )

        with pd.ExcelWriter(file_path) as writer:
            df_database_schema_info.to_excel(writer, sheet_name='database_schema_info', index=False)
            df_collection_schema_info.to_excel(writer, sheet_name='collection_schema_info', index=False)
            df_collection_index_details.to_excel(writer, sheet_name='collection_index_details', index=False)
            df_doc_schema_details.to_excel(writer, sheet_name='doc_schema_details', index=False)

        
    @staticmethod
    def database_schema_info_to_tabular_format(obj: DatabaseSchemaInfoModel):
        
        return _dict_to_json_serializable({
            k: v
            for k, v in obj.model_dump().items()
            if k != 'collection_schema_info'
        })
        
    @staticmethod
    def collection_schema_info_to_tabular_format(obj: DatabaseSchemaInfoModel):
        
        collection_schema_info_tabular_format = []
        for col_nm, collection_detail in obj.collection_schema_info.items():
            tmp = {
                k: v
                for k, v in collection_detail.model_dump().items()
                if k not in ['doc_schema_info', 'index_details']
            }
            
            tmp['ttl_index_size'] = collection_detail.index_details.ttl_index_size
            collection_schema_info_tabular_format.append(tmp)
        
        return _dict_to_json_serializable(collection_schema_info_tabular_format)
    
    @staticmethod
    def collection_index_details_to_tabular_format(obj: DatabaseSchemaInfoModel):
        
        collection_index_details_tabular_format = []
        for col_nm, collection_detail in obj.collection_schema_info.items():
            
            ttl_size = collection_detail.index_details.index_sizes
            settings = collection_detail.index_details.settings
            tmp_settings = copy.deepcopy(settings)
            
            for index_name in tmp_settings.keys():
                
                try:
                    tmp_settings[index_name]['index_size'] += ttl_size.get(index_name, 0)
                except:
                    tmp_settings[index_name]['index_size'] = ttl_size.get(index_name, 0)
            
                tmp_settings[index_name]['db_nm'] = collection_detail.db_nm
                tmp_settings[index_name]['col_nm'] = collection_detail.col_nm
                tmp_settings[index_name]['collection_ns'] = collection_detail.collection_ns
                tmp_settings[index_name]['index_name'] = index_name
                tmp_settings[index_name]['fetch_datetime'] = collection_detail.fetch_datetime
                
                collection_index_details_tabular_format.append(tmp_settings[index_name])
                
        return _dict_to_json_serializable(collection_index_details_tabular_format)
    
    @staticmethod
    def doc_schema_info_to_tabular_format(obj: DatabaseSchemaInfoModel):
        
        doc_schema_info_tabular_format = []
        for col_nm, collection_detail in obj.collection_schema_info.items():
            
            for data_nm, data_schema in collection_detail.doc_schema_info.items():
                
                doc_schema_info_tabular_format.append({
                    'db_nm': collection_detail.db_nm,
                    'col_nm': collection_detail.col_nm,
                    'collection_ns': collection_detail.collection_ns,
                    'fetch_datetime': collection_detail.fetch_datetime,
                    **data_schema.model_dump()
                })
                
        return _dict_to_json_serializable(doc_schema_info_tabular_format)