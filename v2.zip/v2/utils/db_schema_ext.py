#%%
from pymongo import MongoClient
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import List

from models.db_schema_models import DatabaseSchemaInfoModel
from utils.col_schema_ext import CollectionSchemaExtractor

class DatabaseSchemaExtractor:
    
    def __init__(self, db_nm: str, mongo_client: MongoClient, ls_col_nm: List[str] = None):
        
        self.db_nm = db_nm
        self.database_schema_info = DatabaseSchemaInfoModel()
        self.ls_col_nm = ls_col_nm
        
        self.get_schema(mongo_client = mongo_client)
        self.get_collection_schema(mongo_client = mongo_client)
        
    def get_schema(self, mongo_client: MongoClient):
        
        try:
            self.database_schema_info.fetch_datetime = datetime.now(ZoneInfo("Asia/Hong_Kong"))
            if self.db_nm not in mongo_client.list_database_names():
                raise ValueError(f"Database {self.db_nm} not found")
            
            db_stats = mongo_client[self.db_nm].command("dbstats")
            
            self.database_schema_info.host = mongo_client.address[0]
            self.database_schema_info.port = mongo_client.address[1]
            self.database_schema_info.db_nm = self.db_nm
            self.database_schema_info.n_views = db_stats.get('views', None)
            self.database_schema_info.n_collections = db_stats.get('collections', None)
            self.database_schema_info.n_documents = db_stats.get('objects', None)
            self.database_schema_info.avg_document_data_size = db_stats.get('avgObjSize', None)
            self.database_schema_info.document_data_size = db_stats.get('dataSize', None)
            self.database_schema_info.document_storage_size = db_stats.get('storageSize', None)
            self.database_schema_info.ttl_n_indexes = db_stats.get('indexes', None)
            self.database_schema_info.ttl_index_size = db_stats.get('indexSize', None)
        except Exception as e:
            self.database_schema_info.extract_error = str(e)
            
    def get_collection_schema(self, mongo_client: MongoClient, ls_col_nm: List[str] = None, n_doc_to_derive: int = None, fetch_doc_batch_size: int = 1000):
        
        tgt_col_nms = mongo_client[self.db_nm].list_collection_names() if ls_col_nm is None else ls_col_nm
        
        for col_nm in tgt_col_nms:
            
            col_schema_ext = CollectionSchemaExtractor(
                db_nm=self.db_nm, 
                col_nm=col_nm, 
                mongo_client=mongo_client, 
                n_doc_to_derive=n_doc_to_derive, 
                fetch_doc_batch_size=fetch_doc_batch_size
            )
            
            self.database_schema_info.collection_schema_info[col_nm] = col_schema_ext.collection_schema_info