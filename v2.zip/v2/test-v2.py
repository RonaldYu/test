#%%
from utils.doc_schema_ext import DocSchemaExtractor
from utils.general_opr import _dict_to_json_serializable
from datetime import datetime
# %%
# Simple Test 1
docs = [{"x21": 1}, {"x22": 33}, {"x22": 33, "x44": 123}, 33]

derived_schema_results = DocSchemaExtractor.derive_schema(docs)
{
    k: v.model_dump()
    for k, v in derived_schema_results.items()
}

#%%
derived_schema_results = DocSchemaExtractor.derive_schema([])
{
    k: v.model_dump()
    for k, v in derived_schema_results.items()
}
#%%
# Simple Test 2
from datetime import datetime
docs = [
    {
        # "x3": [],
        # "x2": [{"x21": 1}, {"x22": 33}, {"x22": 33, "x44": 123}, 33],
        "x1": [1, "a", None],
        # 'x4': None
    },
    {
        # "x3": [],
        "x2": [{"x21": 1}, {"x22": 33}, {"x22": 33, "x44": 123}, 33, None],
        "x1": [1, "a", None, datetime.now()],
        # 'x4': 1
    },
    {'x1': None}
]

derived_schema_results = DocSchemaExtractor.derive_schema(docs)
{
    k: v.model_dump_json()
    for k, v in derived_schema_results.items()
}
# %%
_dict_to_json_serializable(
    obj = derived_schema_results
)

# %%
from models.col_schema_models import DocSchemaDetailsModel, CollectionSchemaInfoModel

DocSchemaDetailsModel()
# %%
CollectionSchemaInfoModel().model_dump()
# %%
