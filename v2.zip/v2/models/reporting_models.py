#%%
from pydantic import BaseModel, Field
from typing import List, Optional
from models.db_schema_models import DatabaseSchemaInfoModel

class DatabaseSchemaReportingModel(BaseModel):
    
    host: Optional[str] = Field(default=None, description="The host of the database")
    list_database_schema_info: List[DatabaseSchemaInfoModel] = Field(default_factory=list, description="The list of database schema info")