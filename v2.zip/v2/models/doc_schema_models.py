#%%
from __future__ import annotations
from typing import List, Optional, Any, Set, ClassVar
from pydantic import BaseModel, Field
from datetime import datetime



class DocumentSchemaInfoModel(BaseModel):
    
    path: Optional[str] = Field(default=None, description="The path of the data")
    data_type: Set = Field(default_factory=set, description="The type of the data")
    nullable: Optional[bool] = Field(default=None, description="Whether the data is nullable")
    n_docs: int = Field(default=0, description="The number of documents")
    contains_object: Optional[bool] = Field(default=None, description="Whether the data contains an object")
    contains_array: Optional[bool] = Field(default=None, description="Whether the data contains an array")
    parent_path: Set[str] = Field(default_factory=set, description="The parent path of the data")
    parent_data_type: Set[str] = Field(default_factory=set, description="The parent data type of the data")
    

class DataSchemaInfoModel(BaseModel):
    
    list_data_type: ClassVar[str] = "array"
    null_data_type: ClassVar[str] = "null"
    mapping_data_type: ClassVar[str] = "object"
    root_data_nm: ClassVar[str] = ""
    array_item_data_nm: ClassVar[str] = "[]"

    
    # Instance fields
    data_nm: Optional[str] = Field(default=None, description="The name of the data field")
    data_type: Optional[str] = Field(default=None, description="The type of the data")
    parent_data_nm: Optional[str] = Field(default=None, description="The name of the parent data field")
    parent_data_type: Optional[str] = Field(default=None, description="The type of the parent data field")
    children: List[DataSchemaInfoModel] = Field(default_factory=list, description="List of child schema nodes")
    
    def add_child(self, child: DataSchemaInfoModel) -> None:
        self.children.append(child)

class FlattenDataSchemaInfoModel(BaseModel):
    
    path: str = Field(..., description="The path of the data")
    data_type: str = Field(..., description="The type of the data")
    parent_path: Optional[str] = Field(default=None, description="The path of the parent data")
    parent_data_type: Optional[str] = Field(default=None, description="The type of the parent data")
