#%%
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any, Annotated
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import defaultdict

from models.doc_schema_models import DocumentSchemaInfoModel

class IndexDetailsModel(BaseModel):
    
    ttl_index_size: Optional[float] = Field(default=None, description="The size of the TTL index")
    index_sizes: Dict[str, Any] = Field(default_factory=dict, description="The sizes of the indexes")
    settings: Dict[str, Any] = Field(default_factory=dict, description="The settings of the indexes")


class DocSchemaDetailsModel(BaseModel):
    
    extract_error: Optional[str] = Field(default=None, description="The error of the extraction")
    fetch_datetime: datetime = Field(default_factory=datetime.now(ZoneInfo("Asia/Hong_Kong")), description="The datetime of the fetch")
    doc_schema_details: Annotated[
        defaultdict[str, Annotated[DocumentSchemaInfoModel, Field(default_factory=DocumentSchemaInfoModel)]], 
        Field(default_factory=lambda: defaultdict(lambda: DocumentSchemaInfoModel()), description="The details of the document schema")
    ]

class CollectionSchemaInfoModel(BaseModel):
    
    db_nm: Optional[str] = Field(default=None, description="The name of the database")
    col_nm: Optional[str] = Field(default=None, description="The name of the collection")
    collection_ns: Optional[str] = Field(default=None, description="The namespace of the collection")
    document_data_size: Optional[float] = Field(default=None, description="The size of the documents in the collection")
    n_documents: Optional[int] = Field(default=None, description="The number of documents in the collection")
    avg_document_data_size: Optional[float] = Field(default=None, description="The average size of the documents in the collection")
    document_storage_size: Optional[float] = Field(default=None, description="The storage size of the documents in the collection")
    index_details: IndexDetailsModel = Field(default_factory=IndexDetailsModel, description="The details of the indexes in the collection")
    fetch_datetime: datetime = Field(default_factory=lambda: datetime.now(ZoneInfo("Asia/Hong_Kong")), description="The datetime of the fetch")
    extract_error: Optional[str] = Field(default=None, description="The error of the extraction")
    
    
    doc_schema_info: Annotated[
        defaultdict[str, Annotated[DocumentSchemaInfoModel, Field(default_factory=DocumentSchemaInfoModel)]], 
        Field(default_factory=lambda: defaultdict(lambda: DocumentSchemaInfoModel()), description="The details of the document schema")
    ]
