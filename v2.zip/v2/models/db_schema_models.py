#%%
from optparse import Option
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Annotated
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo

from models.col_schema_models import CollectionSchemaInfoModel

class DatabaseSchemaInfoModel(BaseModel):
    
    host: Optional[str] = Field(default=None, description="The host of the database")
    port: Optional[int] = Field(default=None, description="The port of the database")
    db_nm: Optional[str] = Field(default=None, description="The name of the database")
    n_views: Optional[int] = Field(default=None, description="The number of views in the database")
    n_collections: Optional[int] = Field(default=None, description="The number of collections in the database")
    n_documents: Optional[int] = Field(default=None, description="The number of documents in the database")
    avg_document_data_size: Optional[float] = Field(default=None, description="The average size of the documents in the database")
    document_data_size: Optional[float] = Field(default=None, description="The size of the documents in the database")
    document_storage_size: Optional[float] = Field(default=None, description="The storage size of the documents in the database")
    ttl_n_indexes: Optional[int] = Field(default=None, description="The number of TTL indexes in the database")
    ttl_index_size: Optional[float] = Field(default=None, description="The size of the TTL indexes in the database")
    fetch_datetime: datetime = Field(default_factory=lambda: datetime.now(ZoneInfo("Asia/Hong_Kong")), description="The datetime of the fetch")
    extract_error: Optional[str] = Field(default=None, description="The error of the extraction")
    
    
    collection_schema_info: Annotated[
        defaultdict[str, Annotated[CollectionSchemaInfoModel, Field(default_factory=CollectionSchemaInfoModel)]], 
        Field(default_factory=lambda: defaultdict(lambda: CollectionSchemaInfoModel()), description="The details of the collection schema")
    ]
# %%

