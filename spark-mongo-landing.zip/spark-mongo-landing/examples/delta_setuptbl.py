from pyspark.sql import SparkSession


class SetDeltaTBL:

    def __init__(
        self, 
        spark: SparkSession,
        schema_nm: str,
        raw_tbl_nm: str,
        landing_tbl_nm: str
    ):
        
        self.spark = spark
        self.schema_nm = schema_nm
        self.raw_tbl_nm = raw_tbl_nm
        self.landing_tbl_nm = landing_tbl_nm

        self.full_raw_tbl_nm = f"{self.schema_nm}.{self.raw_tbl_nm}"
        self.full_landing_tbl_nm = f"{self.schema_nm}.{self.landing_tbl_nm}"

    
    def reset_tbl(self):
        

        self.spark.sql(f"""
        drop table if exists {self.full_raw_tbl_nm}
        """)

        self.spark.sql(f"""
        CREATE SCHEMA IF NOT EXISTS {self.schema_nm}
        """)

        self.spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {self.full_raw_tbl_nm} (
            _id STRING,
            json_doc STRING,
            ingestion_dt TIMESTAMP
        )
        USING delta
        """)

        self.spark.sql(f"""
        drop table if exists {self.full_landing_tbl_nm}
        """)

        self.spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {self.full_landing_tbl_nm} (
            ingestion_dt TIMESTAMP
        )
        USING delta
        """)