from datetime import (
    datetime,
    timezone,
    timedelta,
    date
)

from pymongo import MongoClient

from utils.mongo_opr import mongo_client_ctx

class GenMongoExamples:

    def __init__(self, connection_str: str, db_nm: str, collection_nm: str):

        self.db_nm = db_nm
        self.collection_nm = collection_nm
        self.connection_str = connection_str

    def drop_collection(self):
        with mongo_client_ctx(self.connection_str) as mongo_client:
            mongo_client[self.db_nm].drop_collection(self.collection_nm)
    
    def insert_example1(self):
        examples_1 = self.get_example1_data()
        with mongo_client_ctx(self.connection_str) as mongo_client:
            mongo_client = mongo_client
            mongo_client[self.db_nm][self.collection_nm].insert_many(examples_1)

    def insert_example2(self):
        examples_2 = self.get_example2_data()
        with mongo_client_ctx(self.connection_str) as mongo_client:
            mongo_client[self.db_nm][self.collection_nm].insert_many(examples_2)

    @staticmethod
    def get_example1_data():
        create_dt = datetime.now(timezone.utc).astimezone(timezone.utc).astimezone(timezone(timedelta(hours=8)))
        examples_1 = [
            {
                "name": "Order",
                "create_dt": create_dt,
                "items": [
                    {"product": "Book", "qty": 2, "price": 12.99},
                    {"product": "Pen", "qty": 5, "color": "blue"}
                ]
            },
            {
                "name": "User",
                "create_dt": create_dt,
                "contacts": [
                    {"type": "email", "value": "user@example.com"},
                    {"type": "phone", "number": "123-456-7890", "verified": True}
                ]
            },
            {
                "name": "Project",
                "create_dt": create_dt,
                "tasks": [
                    {"title": "Design", "due": "2024-07-01"},
                    {"title": "Develop", "assigned_to": ["Alice", "Bob"], "status": "in progress"}
                ]
            },
            {
                "name": "Blog",
                "create_dt": create_dt,
                "comments": [
                    {"user": "john", "comment": "Great post!", "likes": 10},
                    {"user": "jane", "comment": "Thanks for sharing", "replies": [{"user": "admin", "comment": "You're welcome!"}]}
                ]
            }
        ]
        
        return examples_1


    @staticmethod
    def get_example2_data():
        create_dt = datetime.now(timezone.utc).astimezone(timezone.utc).astimezone(timezone(timedelta(hours=8)))
        examples_2 = [
            {
                "name": "Blog1",
                "create_dt": create_dt,
                "comments": [
                    {"user": "john", "comment2": "Great post!", "likes": 10},
                    {"user": "jane", "comment": "Thanks for sharing", "replies1": [{"user": "admin", "comment": "You're welcome!"}]},
                    {"user": "jane", "comment": "Thanks for sharing", "replies1": [{"user1": "admin", "comment1": "You're welcome!"}]}
                ]
            },
            {
                "name": "Survey",
                "create_dt": create_dt,
                "responses": [
                    {"question": 1, "answer": "Yes"},
                    {"question": 2, "answer": ["Option A", "Option C"], "confidence": 0.8}
                ]
            }
        ]
        
        return examples_2
