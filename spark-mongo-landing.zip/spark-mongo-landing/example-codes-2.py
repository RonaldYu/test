# Databricks notebook source
import pyspark.sql.functions as psql_funcs

# COMMAND ----------

connection_str = ""

mongo_db_nm, mongo_col_nm = 'test-db', 'examples'

schema_nm, raw_table_nm, landing_table_nm = "test_schema", "raw_examples", "landing_examples"

full_raw_table_nm, full_landing_table_nm = f"{schema_nm}.{raw_table_nm}", f"{schema_nm}.{landing_table_nm}"

# COMMAND ----------

from utils.spark_mongoloader import SparkMongoLoader
from utils.spark_schemainf import SparkSchemaMerger

# COMMAND ----------

from examples.delta_setuptbl import SetDeltaTBL
from examples.mongo_genex import GenMongoExamples


# COMMAND ----------

# MAGIC %md
# MAGIC # Initialize the storages

# COMMAND ----------

gen_mongoex = GenMongoExamples(
    connection_str = connection_str,
    db_nm = mongo_db_nm,
    collection_nm = mongo_col_nm
)

# COMMAND ----------

gen_mongoex.drop_collection()

# COMMAND ----------

# DBTITLE 1,Cell 13
set_deltatbl = SetDeltaTBL(
    spark = spark,
    schema_nm = schema_nm,
    raw_tbl_nm = raw_table_nm,
    landing_tbl_nm = landing_table_nm
)



# COMMAND ----------

set_deltatbl.reset_tbl()

# COMMAND ----------

gen_mongoex.insert_example1()
gen_mongoex.insert_example2()
gen_mongoex.insert_example1()
gen_mongoex.insert_example2()
gen_mongoex.insert_example2()

# COMMAND ----------

# MAGIC %md
# MAGIC # Process

# COMMAND ----------

spark_mongoloader = SparkMongoLoader(
    spark = spark,
    mongo_connection_str = connection_str,
    mongo_db_nm = mongo_db_nm,
    mongo_collection_nm = mongo_col_nm,
    full_raw_tbl_nm = full_raw_table_nm,
    full_landing_tbl_nm = full_landing_table_nm
)


# COMMAND ----------

from pymongo import MongoClient

mongo_client = MongoClient(connection_str)
ids = list(mongo_client[mongo_db_nm][mongo_col_nm].find({}, {"_id": 1}))
ids = [
    id['_id']
    for id in ids
]

# COMMAND ----------

n_batch = len(ids) // 4

for i in range(n_batch):
    json_rdd = spark_mongoloader.load_mongo_to_spark(
        filter_cond = {"_id": {"$in": ids[i::n_batch]}},
        n_partitions = 5
    )

    spark_mongoloader.load_to_landing_table(
        json_rdd = json_rdd,
        json_doc_col_nm = 'json_doc',
        exclude_revolve_col_nms = ['ingestion_dt', 'json_doc']
    )

# COMMAND ----------

display(
    spark.read.table(full_landing_table_nm)
)

# COMMAND ----------

