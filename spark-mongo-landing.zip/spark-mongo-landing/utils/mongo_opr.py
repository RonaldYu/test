from pymongo import MongoClient
from contextlib import contextmanager

@contextmanager
def mongo_client_ctx(connection_str: str):
  client = MongoClient(
    connection_str
  )
  try:
    yield client
  finally:
    try: client.close()
    except: pass