import json
from datetime import datetime, date, timezone
from bson import ObjectId
from typing import List, Any
from pyspark.rdd import RDD

from pyspark.sql import SparkSession
from utils.mongo_opr import mongo_client_ctx


from pyspark.sql.types import StructType
from pyspark.sql.functions import from_json, col

from utils.spark_schemainf import SparkSchemaMerger

# Custom JSON encoder for MongoDB documents
class JSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, date):
            return obj.isoformat()
        return super().default(obj)


class SparkMongoLoader:

    def __init__(
        self, 
        spark: SparkSession, 
        mongo_connection_str: str, mongo_db_nm: str, mongo_collection_nm: str,
        full_raw_tbl_nm: str, full_landing_tbl_nm: str
    ):

        self.spark = spark
        self.mongo_connection_str = mongo_connection_str
        self.mongo_db_nm = mongo_db_nm
        self.mongo_collection_nm = mongo_collection_nm

        self.full_raw_tbl_nm = full_raw_tbl_nm
        self.full_landing_tbl_nm = full_landing_tbl_nm

    
    def fetch_ids(self, filter_cond: dict) -> List[str]:

        with mongo_client_ctx(self.mongo_connection_str) as mongo_client:

            all_ids = mongo_client[self.mongo_db_nm][self.mongo_collection_nm].find(filter_cond, {"_id": 1})
            all_ids = [str(id["_id"]) for id in all_ids]

        return all_ids

    def load_mongo_to_spark(self, filter_cond: dict, n_partitions: int) -> RDD[Any]:

        # get all ids
        ids = self.fetch_ids(filter_cond)
        ingestion_dt = datetime.now(timezone.utc)

        # parallelize ids
        rdd = self.spark.sparkContext.parallelize([
            ids[i::n_partitions]
            for i in range(n_partitions)
        ])

        mongo_connection_str, mongo_db_nm, mongo_collection_nm = self.mongo_connection_str, self.mongo_db_nm, self.mongo_collection_nm
        # read mongo documents and serialize to json in parallel
        json_rdd = rdd.flatMap(
            lambda ids: SparkMongoLoader.fetch_and_serialize(ids, mongo_connection_str, mongo_db_nm, mongo_collection_nm, ingestion_dt)
        )

        return json_rdd
        

    @staticmethod
    def fetch_and_serialize(ids: List[str], connection_str: str, db_nm: str, col_nm: str, ingestion_dt: datetime):

        with mongo_client_ctx(connection_str) as mongo_client:
            collection = mongo_client[db_nm][col_nm]
            results = []

            for _id in ids:
                doc = collection.find_one({"_id": ObjectId(_id)})
                if doc:
                    results.append({'_id': _id, 'json_doc': json.dumps(doc, cls=JSONEncoder), 'ingestion_dt': ingestion_dt})

        return results

    
    def load_to_raw_table(self, json_rdd: RDD[Any]):

        col_names = self.spark.read.table(self.full_raw_tbl_nm).columns
        self.spark.createDataFrame(json_rdd).select(*col_names).write.insertInto(self.full_raw_tbl_nm)

    
    def load_to_landing_table(self, json_rdd: RDD[Any], json_doc_col_nm: str, exclude_revolve_col_nms: List[str] = []):

        # get new schema
        new_schema = self.spark.createDataFrame(json_rdd) \
            .selectExpr(f"schema_of_json_agg({json_doc_col_nm}) as merged_schema") \
            .collect()[0]['merged_schema']
        
        new_schema = StructType.fromJson(
            json.loads(
                self.spark._jsparkSession.sessionState().sqlParser().parseDataType(new_schema).json()
            )
        )

        # get the current landing table schema
        cur_landing_schema = self.spark.read.table(self.full_landing_tbl_nm).schema
        cur_landing_schema = StructType([
            field for field in cur_landing_schema.fields if field.name not in exclude_revolve_col_nms
        ])
        # merge the current landing table schema with the new schema
        merged_schema = SparkSchemaMerger.merge_schemas(cur_landing_schema, new_schema)

        self.spark.createDataFrame(json_rdd) \
            .withColumn(
                "parsed_json_doc",
                from_json(col(json_doc_col_nm), merged_schema)
            ) \
            .select(
                "parsed_json_doc.*",
                *[col_nm for col_nm in exclude_revolve_col_nms]
            ) \
            .write.option("mergeSchema", "true").mode("append").saveAsTable(self.full_landing_tbl_nm)