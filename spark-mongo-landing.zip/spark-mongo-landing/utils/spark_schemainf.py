from pyspark.sql.types import (
    DataType, StructType, StructField, ArrayType, MapType,
    DateType, TimestampType, StringType, BooleanType,
    DecimalType, ShortType, ByteType, IntegerType, LongType, FloatType, DoubleType
)

class SparkSchemaMerger:

    @staticmethod
    def merge_type(type_1: DataType, type_2: DataType) -> DataType:

        if type_1 == type_2: return type_1

        # numeric types
        numeric_types = {
            ByteType: 1,
            ShortType: 2,
            IntegerType: 3,
            LongType: 4,
            FloatType: 5,
            DoubleType: 6,
        }
        
        type_1_numeric = type(type_1) in numeric_types
        type_2_numeric = type(type_2) in numeric_types

        if type_1_numeric and type_2_numeric:

            if numeric_types[type(type_1)] > numeric_types[type(type_2)]:
                return type_1
            else:
                return type_2
        
        ## decimal types
        type_1_decimal = isinstance(type_1, DecimalType)
        type_2_decimal = isinstance(type_2, DecimalType)

        if type_1_decimal and type_2_decimal:
            
            precision = max(type_1.precision, type_2.precision)
            scale = max(type_1.scale, type_2.scale)

            return DecimalType(precision=precision, scale=scale)
            
        if (type_1_decimal and type_2_numeric) or (type_2_decimal and type_1_numeric): 
            return DoubleType()

        # datetime-related types
        if isinstance(type_1, DateType) and isinstance(type_2, TimestampType):
            return TimestampType()
        
        if isinstance(type_1, TimestampType) and isinstance(type_2, DateType):
            return TimestampType()

        
        raise ValueError(f"Cannot merge {type_1} and {type_2}")


    
    @staticmethod
    def _merge_data_type(type_1: DataType, type_2: DataType) -> DataType:
        """
        Helper method to merge two DataTypes (including nested structures).
        Uses merge_schemas for StructType and merge_type for primitive types.
        """
        # Both are StructType -> use merge_schemas
        if isinstance(type_1, StructType) and isinstance(type_2, StructType):
            return SparkSchemaMerger.merge_schemas(type_1, type_2)
        
        # Both are ArrayType -> merge elementType recursively
        if isinstance(type_1, ArrayType) and isinstance(type_2, ArrayType):
            merged_elem = SparkSchemaMerger._merge_data_type(type_1.elementType, type_2.elementType)
            return ArrayType(merged_elem, type_1.containsNull or type_2.containsNull)
        
        # Both are MapType -> merge keyType and valueType
        if isinstance(type_1, MapType) and isinstance(type_2, MapType):
            merged_key = SparkSchemaMerger._merge_data_type(type_1.keyType, type_2.keyType)
            merged_value = SparkSchemaMerger._merge_data_type(type_1.valueType, type_2.valueType)
            return MapType(merged_key, merged_value, type_1.valueContainsNull or type_2.valueContainsNull)
        
        # Otherwise, use merge_type for primitive types
        return SparkSchemaMerger.merge_type(type_1, type_2)
    
    @staticmethod
    def merge_schemas(schema_1: StructType, schema_2: StructType) -> StructType:
        """
        Merge schema_2 into schema_1.
        For fields with the same name, merge their types using merge_type.
        New fields from schema_2 are appended to schema_1.
        """
        if not isinstance(schema_1, StructType) or not isinstance(schema_2, StructType):
            raise ValueError("Both schema_1 and schema_2 must be StructType")
        
        # Create a dictionary to store fields, starting with schema_1
        fields_dict = {f.name: f for f in schema_1.fields}
        
        # Iterate through schema_2 fields
        for f2 in schema_2.fields:
            if f2.name not in fields_dict:
                # New field from schema_2, add it
                fields_dict[f2.name] = f2
            else:
                # Field exists in both schemas, merge them
                f1 = fields_dict[f2.name]
                
                try:
                    # Use _merge_data_type to handle all cases (StructType, ArrayType, MapType, primitives)
                    merged_type = SparkSchemaMerger._merge_data_type(f1.dataType, f2.dataType)
                    fields_dict[f2.name] = StructField(
                        f2.name,
                        merged_type,
                        f1.nullable or f2.nullable
                    )
                except ValueError:
                    # If merge fails, use schema_2's type (override)
                    fields_dict[f2.name] = f2
        
        # Preserve schema_1's field order, then append new fields from schema_2
        ordered_fields = []
        # Add fields from schema_1 in original order
        for f in schema_1.fields:
            ordered_fields.append(fields_dict[f.name])
        # Add new fields from schema_2
        for f in schema_2.fields:
            if f.name not in schema_1.fieldNames():
                ordered_fields.append(fields_dict[f.name])
        
        return StructType(ordered_fields)
        